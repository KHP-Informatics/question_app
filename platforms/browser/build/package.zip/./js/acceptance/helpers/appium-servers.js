exports.local = {
  host: 'localhost',
  port: 4723
};
